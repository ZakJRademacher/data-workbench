# Studio visual design

The 2.0.1 presentation refresh keeps processing rules and project history unchanged. The original 2.0.0 download and benchmark evidence remain available.

The near-black canvas makes dense tables and light text easy to distinguish. Blue identifies actions; orange identifies the current step. Green, gold and rose messages retain separate success, warning and error meanings, with explanatory text. Table containers scroll independently on narrow screens.

The parsed-record breakdown uses the actual saved manifest: accepted, review and excluded populations appear as labeled segments. Their reveal and short screen transitions explain progress without counting up or changing final values. Unreadable-file populations remain explicitly unknown. Motion stops under the operating system's reduced-motion preference; no decorative loop or parallax is used.

The current interface adds a floating sidebar, layered source cards, a custom vector intake graphic and a donut displaying accepted share. The blue/apricot chart has its own labeled categorical legend; success, warning and error messages retain explicit text and distinct message colors. Accepted share is rule disposition, not a measure of factual accuracy. With no parsed rows, the center shows a dash and `NO PARSED ROWS` rather than a fabricated percentage. Rapid tab navigation resolves to the last requested step, and browsers without View Transitions use the ordinary tab behavior.

The separate motion-study page presents a recording of the app. Its frame entrance and chapter controls are presentation effects; they do not run on the working data table. The app itself remains a local preparation tool. Native workbook exports are static.

Palette values live in `web/design-tokens.json`. Run `python -B tools/build_theme.py` after changing them. This regenerates `web/theme-tokens.css`; `web/studio.css` controls the visual composition over the existing component structure. No external font download is needed.


The browser workflow check covers upload, corrections, relationship approval and downloads. `tools/capture_visual_pilot.py` captures actual fictional demo screens and checks narrow-screen page overflow; use scratch projects outside this repository. Historical benchmark evidence continues to identify the release originally tested.

## Portfolio thumbnails

The shared cover uses a large title, a short tool line and a straight-on project screenshot. `presentation/cover.json` selects the existing source image and its scope label; `presentation/cover-template.html` controls the layout. `portfolio-cover.png` is the 1280 × 960 cover used on the GitHub profile and Upwork. `portfolio-cover-wide.png` is the 1280 × 720 variant. The repository README keeps its larger original report or app preview.

Run the existing `python presentation/build_cover.py --workdir <scratch folder>` to regenerate static covers after a source or title change. The template has no decorative entrance animation. Workbench uses a top crop for the thumbnail; its full workspace screenshot remains available. Keep the source qualifications when changing a cover.
