# Operating Data Workbench

The fictional demo shows the full workflow: inspect files, choose rules, review exceptions, and join the corrected tables. Start there before adding your own exports.

## The first five minutes

1. Open **Data Workbench** from the Start menu (or `Start Workbench.cmd` in the ZIP download) and choose **Explore the demo**.
2. Inspect the four source files. The February workbook has a title row, so the app selects row 2 as its header. CSV and Excel order exports map into the same `orders` table despite alternate headings.
3. Open **Recipe & relationships**. Text keeps IDs such as `001`. Customers use `customer_id` as a key; orders use `order_id`; payments use `payment_id`. The saved region mapping changes `E` to `East`.
4. Click **Run project**. The result has 20 parsed rows, 14 accepted, and 6 requiring review. The raw inputs are unchanged.
5. Open **Results & review**, choose `orders`, and show **Needs review**. **Inspect / correct** displays original values, issues, and editable corrections.

## Resolve the fictional demo

For this fictional demo, use the following stated corrections. Real source corrections would need supporting evidence:

- For order `O102`, check the `order_date` correction box and enter `2026-01-05`. The demo's intended date is January 5; the app does not infer that from `01/05/2026`.
- For order `O104`, correct `amount` to `30.00`, the demo's intended value.
- For the customer copy named `June B.`, choose **Explicitly exclude**. The demo retains the `June Brooks` customer record.
- In the orders recipe, change duplicates to **Exclude exact repeats**. This policy keeps one valid copy of `O106` and records the other as excluded.
- Save and rerun. Expect **20 = 18 accepted + 0 review + 2 excluded** (5 customers, 7 orders, 6 payments), with **7 accepted orders totaling 625.9750** source units.

## Connect the tables without multiplying orders

1. After the corrected table run, open **Recipe & relationships**.
2. Add a combined view named `orders_combined` with base `orders`.
3. Add `customers` as a left lookup: base key `customer_id`, lookup key `customer_id`.
4. Add `payments` as a left lookup: base key `order_id`, lookup key `order_id`.
5. Add a child aggregation for payments: **sum**, field `paid_amount`, output `paid_total`. Payment `P1` and `P2` belong to the same order; directly joining both would repeat that order's amount.
6. Click **Preview joins**. Expect **7 → 7 rows**. One base order has no accepted customer match. Three base orders have no payment match. A missing payment stays missing, rather than being treated as zero.
7. Approve the relationships and rerun. `O100` has a `payments__paid_total` of **125.5000**. Payment `P5` references `O999`, which is absent from the orders base; the payment remains in the clean payments table and audit.

Inner joins are available only by explicit choice and show the number of base records they would remove. Repeated lookup keys block a join until you resolve them or aggregate the child table. Composite keys use comma-separated field names in corresponding order.

## Use your own files

- Create a project, add the files, and confirm sheet/header settings in **Inspect & configure**. Set the optional last data row to stop before a footer or totals section. Records outside the selected boundary are outside the imported table; the complete original file is retained. Uploads are copied into project storage; the originals are untouched.
- Generate a starting recipe. A narrow built-in alias list recognizes headings such as `Cust ID` and `Customer ID`; matching column signatures may be grouped. Confirm that the proposed tables mean the same thing.
- To combine additional exports, use **Move to** to assign a source to an existing table, then **Map columns**. New fields are preserved; omitted source columns require an explicit choice.
- Use **Configure** beside a field to set date order, decimal/thousands separators, missing markers, category mappings, allowed values, or bounds. Blank optional values stay missing.
- When files use different conventions, open **Source format** beside a source mapping. Give the format a reusable name, enable the parsing overrides that differ, and assign it to other matching exports. Add `NA` as a missing marker for a specific field when that source uses it for missing data. A field-level missing marker applies across all sources in that table.
- Decimal fields support a maximum fractional scale. **Reject any extra fractional digit** holds `12.34000` under a four-place contract. **Ignore redundant trailing zeros** is the default. Select **Round to the selected decimal places** to round decimal values explicitly. Exact ties round away from zero, so at two places `1.235` becomes `1.24` and `-1.235` becomes `-1.24`. Enable case-insensitive categories when `furniture` should become the allowlisted `Furniture`.
- **Cross-field checks** allows comparisons such as `ship_date >= order_date`. These run after parsing and before duplicate checks. Make the operands Required if a missing value must also be held.
- Type suggestions sample the beginning, middle and end of the selected data. Confirm identifiers as **Text**, especially unfamiliar headings. Choose **Timestamp (UTC)** to keep ISO date and time, with optional numeric offset or `Z`. A value without an offset is interpreted as UTC. Invalid values enter review. Choose **Date** for dates and midnight Excel timestamps.
- Confirm the header in source settings. For a partial import, set **Malformed rows** to **Hold rows with extra or missing cells**. Workbench keeps CSV records with the wrong cell count and Excel rows with values beyond the headings in the review queue. The package marks partial results and includes the original values. Invalid CSV quoting that prevents record boundaries from being read remains a file-level error.
- Select keys only when they identify the intended record grain. A key can contain several fields. Default repeated-record behavior is review; choose keep-all or exclusion only when justified.
- Run the project. Resolve file issues before treating the outputs as a complete project. Fix row issues through corrections or source replacement, then rerun.

## Refresh an existing project

Use **Replace file** on the source card. This keeps its source slot and saved mapping while retaining the old bytes. Reinspect the selected header and sheet. A new column must be mapped or explicitly omitted; a missing mapped column blocks execution until corrected.

Unchanged source bytes, filenames, settings, rules, and decisions reuse a verified result. New source versions get new record IDs, so old row corrections are not silently applied to replacement files. Reusable field/category rules remain in the recipe.

Version 2 reads version-1 recipes with their previous defaults, then saves new edits as version 2. Raw files, review decisions, prior input snapshots and completion manifests remain on disk. A changed engine build triggers a fresh run. Older versions reject version-2 recipes; keep a source backup before downgrading and do not edit historical snapshots to make them load.

## Understand the outputs

- `<table>.csv`: all accepted records, including source references.
- `<table>-review.csv`: all held records and their reasons.
- `<table>-excluded.csv`: every explicitly excluded row or duplicate copy, with a reason.
- `<view>.csv`: approved, combined tables at the selected base grain.
- `<view>-unmatched-*.csv`: base records without a lookup and lookup records without a base match, separately for each relationship. These remain available even when an inner join omits unmatched base records.
- `audit.csv`: raw values, prepared values, record disposition, provenance, and issues for every parsed record.
- `Review.xlsx`: summary, exact totals, file issues, labeled clean/review previews, and relationship results. Previews stop at 1,000 rows; CSVs are complete.
- `recipe.json`, `decisions.json`, and `data-dictionary.json`: reproducibility and handoff material.
- `data.duckdb`: closed snapshot of clean tables and result/audit tables. Open read-only in a DuckDB-capable tool.
- `manifest.json`: source hashes, output hashes, counts, totals, profiles, and run status. It is published last.

## Limits and interpretation

- Up to **50 sources, 50 MB each, 250 MB combined, and 1,000,000 parsed input rows**. One processing job at a time. Preview pages are bounded; full datasets remain in exports.
- CSV: UTF-8, Windows-1252, or explicitly selected UTF-16. A file is detected as UTF-8 only if the whole file is valid UTF-8; otherwise Windows-1252 is suggested; comma, semicolon, tab, or pipe delimiters. Source references count logical CSV records, including headers, rather than physical lines inside quoted records.
- Excel: `.xlsx`, one selected sheet per source. Split workbooks containing separate tables into sheets or files. Legacy `.xls`, macros, merged analytical layouts, PDF extraction, and automatic formula recalculation are outside this version.
- Formula inputs use the workbook's stored results. Formula text and cache provenance are retained in the audit; freshness is unverified. Missing cached results go to review. Numeric cells with simple zero-padding formats preserve displayed leading zeros.
- Dates require an explicit format. Ambiguous source dates remain text until you choose a rule. Timestamps in ISO form can be normalized to UTC by assigning **Timestamp (UTC)**. Decimal scale supports up to 12 fractional places and 26 whole-number digits. Choose the precision policy in the decimal field rules.
- A relationship suggestion is evidence of compatible data, not proof of business meaning. No fuzzy entity merging, imputation, unit conversion, or currency conversion is performed.
- Field profiles show missing/invalid-null counts and distinct values. Numeric outliers use 1.5 × IQR as a diagnostic only; they are retained.
- File errors make the project **incomplete**. Accepted outputs then cover only readable sources. The app never labels that subset a complete project.
- CSV text that a spreadsheet could run as a formula (`=…`, `@…`, or `+`/`-` followed by anything other than digits, spaces and `.,()/:+-`) is made inert with an apostrophe, and the manifest's `csv_escaped_cells` counts every escaped cell per file. Signed data such as `-67.5, -68.1` or `+44 20 7946 0000` is exported unchanged. The review workbook escapes every value starting with `=`, `+`, `-` or `@`. Original source bytes and raw audit JSON preserve the original text.

## Storage and reproducibility

An installed copy keeps projects in `%LOCALAPPDATA%/DataWorkbench/projects`, outside the program folder, so upgrades and uninstalling never touch them. A ZIP download keeps them in its own `projects/` folder, which is excluded from Git and release downloads. **Storage location** shows the folder in use and can copy projects in from another folder, such as an earlier download: existing projects are never overwritten, each copied file is checked against the original, and runs left unfinished arrive marked interrupted. Payment reconciliations are saved beside the projects, under `reconciliations/`. While a run is processing, its working database and spill files live under `%LOCALAPPDATA%/DataWorkbench/runtime`. They are removed when the run finishes or fails, or on the next start after an interruption; completed packages keep their own closed database copies. Export zips are built there per download and deleted once sent. Old source versions and run snapshots remain available on disk.

Files are processed on your computer. If you store projects in OneDrive, synchronization is handled separately by OneDrive.

Version-1 recipes migrate with earlier option defaults. Historical inputs, decisions and run snapshots are preserved. New recipes use version 2 and cannot be opened by the earlier app.

To move projects, use **Storage location → Bring in projects from another folder**, or close the app and copy each entire `<project-id>/` folder into the destination projects folder. A recipe alone contains source identifiers, so importing it into a different project requires updating its source mappings.

## The desktop window

The app runs as a Windows program: a small local server on a free `127.0.0.1` port and a window that shows it. Closing the window stops the app; if a run is still processing it asks first, and a run closed this way is marked interrupted on the next start. Opening the app again while it is open brings the existing window forward. Its log is `%LOCALAPPDATA%/DataWorkbench/logs/desktop.log`. If the window cannot be created, the app opens in the browser with a terminal window instead; `tools/launch.ps1 -Browser` chooses that mode deliberately.
